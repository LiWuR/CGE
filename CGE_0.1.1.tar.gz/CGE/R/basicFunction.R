#LI Wu (liwu@staff.shu.edu.cn). Shanghai University. Mathematical Economics. updated: 201405

#Compute the PF eigenvalue and eigenvector.
PF_eig<-function (M)
{
  ev<-eigen(M)

  tmp<-Re(ev$values)

  indx<-which(tmp==max(tmp))
  if (length(indx)!=1){
    print(M);   print(ev$values); print(indx)
    stop("Li:PF_eig, none or multiple PF eig value")
  }

  PFVector<-ev$vectors[,indx]
  PFVector<-PFVector/sum(PFVector)
  list(val=abs(ev$values[indx]),vec=abs(PFVector))
}


dg<-function (x){
  if (length(x)==1) return(x)
  if (is.vector(x)||nrow(x)==1||ncol(x)==1) return(diag(c(x)))
  else return(diag(x))
}


F_Z<-function (A,p,S){
  s<-rowSums(S)
  S_bar<-S
  m<-ncol(S)
  for (tk in 1:length(s)) {
    if (s[tk]!=0) S_bar[tk,]<-S_bar[tk,]/s[tk]
  }

  Z<-dg(1/(t(p)%*%A))%*%t(S_bar)%*%dg(p)%*%A

  tmp<-PF_eig(Z)
  z_structure<-tmp$vec

  zeta<-min(s/(A%*%z_structure))
  z=zeta*z_structure;
  q=A%*%z/s
  list(z=z,q=q)
}


CD_A<-function(alpha,Beta,p) {
  #computing Cobb-Douglas demand structure matrix
  if (is.numeric(Beta)&&any(abs(colSums(Beta)-1)>10^-10))
    stop('Li: colSum(Beta)~=1, CD_A')

  A<-dg(1/p)%*%Beta%*%dg(apply((dg(1/p)%*%Beta)^(-Beta),2,prod)%*%dg(1/alpha));
  A
}

CES_A<-function(sigma,alpha,Beta,p){
  #computing CES demand structure matrix
  n<-nrow(Beta)
  m<-ncol(Beta)

  A<-matrix(0,n,m)
  #if isnumeric(sigma)&&isnumeric(alpha)&&isnumeric(Beta)&&isnumeric(p)
  #else
  #  A=sym(zeros(n,m));
  #end;

  for (cn in 1:m){
    e1<-1/(1-sigma[cn]);
    e2<-sigma[cn]/(sigma[cn]-1);
    e3<--1/sigma[cn];
    k<-alpha[cn];
    beta<-Beta[ ,cn];
    for (rn in 1:n){
      A[rn,cn]<-1/k* (beta[rn]/p[rn])^e1 * (sum(beta^e1*p^e2)) ^e3
    }
  }
  A
}

Leontief_mA<-function(A,p){
  #computing Leontief demand structure matrix in a monetary economy
  nonnegativeA<-A;
  nonnegativeA[nonnegativeA<0]<-0;
  Indx<-which(A<0, arr.ind=T)
  for (k in 1:nrow(Indx))
    A[Indx[k,1],Indx[k,2]]<-t(p)%*%nonnegativeA[ ,Indx[k,2]]/(-A[Indx[k,1],Indx[k,2]]);

  A
}

CD_mA<-function(alpha,Beta,p) {
  #computing Cobb-Douglas demand structure matrix in a monetary economy
  nonnegative_Beta<-Beta;
  nonnegative_Beta[Beta<0]<-0;
  A<-CD_A(alpha,nonnegative_Beta,p);
  tmpA<-A;

  Indx<-which(Beta<0, arr.ind=T)
  for (k in 1:nrow(Indx)){
    A[Indx[k,1],Indx[k,2]]<-t(p)%*%tmpA[ ,Indx[k,2]]/(-Beta[Indx[k,1],Indx[k,2]]);
  }
  A
}
CES_mA<-function(sigma,alpha,Beta,p){
  #computing CES demand structure matrix in a monetary economy
  nonnegative_Beta<-Beta;
  nonnegative_Beta[Beta<0]<-0;
  A<-CES_A(sigma,alpha,nonnegative_Beta,p);
  tmpA<-A;

  Indx<-which(Beta<0, arr.ind=T)
  for (k in 1:nrow(Indx)){
    A[Indx[k,1],Indx[k,2]]<-t(p)%*%tmpA[ ,Indx[k,2]]/(-Beta[Indx[k,1],Indx[k,2]]);
  }
  A
}


